<?php 

require_once(ABSPATH . 'wp-content/themes/pb/functions.php');